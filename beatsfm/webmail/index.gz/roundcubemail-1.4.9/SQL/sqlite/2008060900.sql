-- Updates from version 0.2-alpha

CREATE INDEX ix_messages_created ON messages (created);
